package gui;

import java.awt.Container;
import java.awt.Label;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

/**
 * Create the main window frame.
 * 
 * @author lmc
 *
 */
public class MyFrame extends JFrame {
	private static final long serialVersionUID = 1L;
	MenuBar menuBar; // Menu bar
	Menu userMenu, itemMenu; // Menu
	public MenuItem addUser, showUser, delUser, updtUser, showItem, addItem, updtItem, delItem; // Menu Items
	Panel contentPanel; // content panel, all other panel will be shown on that

	public MyFrame() {
		// initial components
		menuBar = new MenuBar();
		userMenu = new Menu("User");
		itemMenu = new Menu("Item");

		addUser = new MenuItem("Add User");
		showUser = new MenuItem("View User");
		delUser = new MenuItem("Delete User");
		updtUser = new MenuItem("Update User");
		showItem = new MenuItem("View Item");
		addItem = new MenuItem("Add Item");
		updtItem = new MenuItem("Update Item");
		delItem = new MenuItem("Delete Item");

		contentPanel = new Panel();

		// connection the menu
		userMenu.add(addUser);
		userMenu.add(showUser);
		userMenu.add(delUser);
		userMenu.add(updtUser);

		itemMenu.add(showItem);
		itemMenu.add(addItem);
		itemMenu.add(updtItem);
		itemMenu.add(delItem);

		menuBar.add(userMenu);
		menuBar.add(itemMenu);

		setMenuBar(menuBar);

		// Set content panel at the center of the frame.
		this.setContentPane(new MyPanel());

		// Other parameter for the frame
		setTitle("Main Window");
		setBounds(100, 100, 768, 512);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	// Change the content panel
	public void changeContentPane(Container contentPane) {
		this.setContentPane(contentPane);
		this.revalidate();
	}

}

// Initial simple panel
class MyPanel extends Panel {
	public MyPanel() {
		this.add(new Label("Welcome to the User and inventory mange system."));
		this.add(new Label("Please use the menu to select service."));
	}
}