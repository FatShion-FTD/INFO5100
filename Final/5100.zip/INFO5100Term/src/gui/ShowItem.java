package gui;

import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import business.Item;
import business.ItemHelper;
import business.SqlConn;

public class ShowItem extends JPanel {
	private SqlConn sqlCon = null;

	/**
	 * Create the item exhibition panel.
	 * 
	 * @throws Exception
	 */
	public ShowItem(SqlConn sql) throws Exception {
		this.sqlCon = sql;

		String[] headers = { "Item Name", "Count", "Unit Price", "Descrip", "LastTime", "Modifier" };
		Object[][] items = ItemHelper.getItemsByObject(sqlCon);
		final JTable table = new JTable(items, headers);
		table.setBackground(Color.YELLOW);
		table.setFillsViewportHeight(true);
		JScrollPane scrollPane = new JScrollPane(table);
		add(scrollPane);
	}
}
