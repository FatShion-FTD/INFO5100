package gui;

import java.awt.Color;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JTable;

import business.SqlConn;
import business.User;
import business.UserHelper;

import javax.swing.JScrollPane;

public class ShowUser extends JPanel {
	private SqlConn sqlCon = null;

	/**
	 * Create the user exihibation panel.
	 * 
	 * @throws Exception
	 */
	public ShowUser(SqlConn sql) throws Exception {
		this.sqlCon = sql;

		String[] headers = { "User Name", "Password", "is Admin" };
		Object[][] users = this.getUsrs();
		final JTable table = new JTable(users, headers);
		table.setBackground(Color.YELLOW);
		table.setFillsViewportHeight(true);
		JScrollPane scrollPane = new JScrollPane(table);
		add(scrollPane);
	}

	/**
	 * Format all the users from List to Object[][]
	 * 
	 * @return
	 * @throws Exception
	 */
	private Object[][] getUsrs() throws Exception {
		List<User> users = UserHelper.getAllUser(sqlCon);
		Object[][] res = new Object[users.size()][3];
		for (int i = 0; i < users.size(); i++) {
			User u = users.get(i);
			res[i][0] = u.getUserName();
			res[i][1] = u.getUserPW();
			res[i][2] = new Boolean(u.isAdmin());
		}

		return res;
	}
}
