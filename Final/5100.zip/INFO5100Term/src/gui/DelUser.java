package gui;

import java.awt.Font;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import business.SqlConn;
import business.UserHelper;

public class DelUser extends JPanel implements ActionListener {
	private SqlConn sqlCon = null;
	private JTextField userNameField;
	private JButton delBtn;

	/**
	 * Create delete user panel.
	 */
	public DelUser(SqlConn sql) {
		this.sqlCon = sql;

		this.setLayout(null);

		JLabel lblNewLabel = new JLabel("Delete User");
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 36));
		lblNewLabel.setBounds(250, 10, 250, 100);
		this.add(lblNewLabel);

		Label label1 = new Label("Delete User Name:");
		label1.setFont(new Font("����", Font.PLAIN, 30));
		label1.setBounds(80, 135, 270, 50);
		this.add(label1);

		userNameField = new JTextField();
		userNameField.setColumns(15);
		userNameField.setFont(new Font("����", Font.PLAIN, 30));
		userNameField.setBounds(450, 135, 250, 50);
		this.add(userNameField);

		delBtn = new JButton("Delete User");
		delBtn.setFont(new Font("����", Font.PLAIN, 25));
		delBtn.setBounds(219, 236, 200, 50);
		delBtn.addActionListener(this);
		this.add(delBtn);
	}

	/**
	 * Button action listener.
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		try {
			String name = userNameField.getText();
			if (!UserHelper.containsUser(sqlCon, name) || name.equals("")) {			// check user exist and name cannot be empty
				userNameField.setText("");
				JOptionPane.showMessageDialog(null, "No Such User existed!");
				return;
			}
			UserHelper.deleteUser(sqlCon, name);										// delete User
			JOptionPane.showMessageDialog(null, "User successfully deleted!");
		} catch (Exception e2) {
			e2.printStackTrace();
		}

	}
}
