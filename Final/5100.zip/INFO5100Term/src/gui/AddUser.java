package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;
import java.awt.Label;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import business.SqlConn;
import business.User;
import business.UserHelper;

public class AddUser extends JPanel implements ActionListener {

	private SqlConn sqlCon = null;
	private JTextField userNameField;
	private JTextField passwordField;
	private JCheckBox isAdmin;
	private JButton addBtn;

	/**
	 * Create the Add user panel.
	 */
	public AddUser(SqlConn sql) {
		this.sqlCon = sql;

		this.setLayout(null);

		JLabel lblNewLabel = new JLabel("Add New User");
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 36));
		lblNewLabel.setBounds(250, 10, 250, 100);
		this.add(lblNewLabel);

		Label label1 = new Label("New User Name:");
		label1.setFont(new Font("����", Font.PLAIN, 30));
		label1.setBounds(80, 135, 250, 50);
		this.add(label1);

		Label label2 = new Label("New User Password:");
		label2.setFont(new Font("����", Font.PLAIN, 30));
		label2.setBounds(80, 228, 300, 50);
		this.add(label2);

		userNameField = new JTextField();
		userNameField.setColumns(15);
		userNameField.setFont(new Font("����", Font.PLAIN, 30));
		userNameField.setBounds(450, 135, 250, 50);
		this.add(userNameField);

		passwordField = new JTextField();
		passwordField.setColumns(15);
		passwordField.setBounds(450, 236, 250, 50);
		this.add(passwordField);

		isAdmin = new JCheckBox("Is Admin Permission");
		isAdmin.setFont(new Font("����", Font.PLAIN, 20));
		isAdmin.setBounds(450, 352, 250, 50);
		this.add(isAdmin);

		addBtn = new JButton("Add User");
		addBtn.setFont(new Font("����", Font.PLAIN, 25));
		addBtn.setBounds(219, 338, 200, 50);
		addBtn.addActionListener(this);
		this.add(addBtn);
	}

	/**
	 * Set input area clear.
	 */
	private void setClear() {
		userNameField.setText("");
		passwordField.setText("");
		isAdmin.setSelected(false);
	}

	/**
	 * Button action listener.
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		try {
			if (source == addBtn) {
				String name = userNameField.getText();
				String pw = passwordField.getText();
				boolean adminPermission = isAdmin.isSelected();

				if (name.equals("") || pw.equals("")) {														// user name and password cannot be empty
					JOptionPane.showMessageDialog(null, "User Name and Password can not be Empty!");
					this.setClear();
					return;
				}

				if (UserHelper.containsUser(sqlCon, name)) {												// Check existence
					JOptionPane.showMessageDialog(null, "User already existed!");
					this.setClear();
					return;
				}
				UserHelper.addUser(sqlCon, new User(name, pw, adminPermission));							// Add new user
				JOptionPane.showMessageDialog(null, "User successfully added!");
				this.setClear();
			}
		} catch (Exception e2) {
			e2.printStackTrace();
		}
	}
}
