package business;

import java.util.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ItemHelper {
	public ItemHelper() {
	}

	/**
	 * Get all tge items in List format
	 * 
	 * @param sqlCon
	 * @return
	 * @throws Exception
	 */
	public static List<Item> getAllItems(SqlConn sqlCon) throws Exception {
		String sql = "SELECT * FROM item";
		ResultSet rs = sqlCon.execQUERY(sql);
		List<Item> res = new ArrayList<>();
		while (rs.next()) {
			res.add(new Item(rs.getString("name"), rs.getInt("count"), rs.getDouble("price"), rs.getString("descript"),
					rs.getString("time"), rs.getString("mod")));
		}
		System.out.println("Succecfully get item list from sql.");
		return res;
	}

	/**
	 * Get one item by its name
	 * 
	 * @param sqlCon
	 * @param itemName
	 * @return
	 * @throws Exception
	 */
	public static Item getOneItem(SqlConn sqlCon, String itemName) throws Exception { // item guarantee existed
		String sql = "SELECT * FROM item WHERE name = ?";
		PreparedStatement pstm = (PreparedStatement) sqlCon.getC().prepareStatement(sql);
		pstm.setString(1, itemName);
		ResultSet rs = pstm.executeQuery();
		Item res = new Item(rs.getString("name"), rs.getInt("count"), rs.getDouble("price"), rs.getString("descript"),
				rs.getString("time"), rs.getString("mod"));
		return res;
	}

	/**
	 * Get All the item in Object[][] format
	 * 
	 * @param sqlCon
	 * @return
	 * @throws Exception
	 */
	public static Object[][] getItemsByObject(SqlConn sqlCon) throws Exception {
		List<Item> items = ItemHelper.getAllItems(sqlCon);
		Object[][] res = new Object[items.size()][Item.LEN];
		for (int i = 0; i < items.size(); i++) {
			Item item = items.get(i);
			res[i][0] = item.getName();
			res[i][1] = new Integer(item.getCount());
			res[i][2] = new Double(item.getUnitPrice());
			res[i][3] = item.getDescript();
			res[i][4] = item.getLastTime();
			res[i][5] = item.getLastUser();
		}
		return res;
	}

	/**
	 * Check whether inventory contains the item, by its name
	 * 
	 * @param sqlCon
	 * @param itemName
	 * @return
	 * @throws Exception
	 */
	public static boolean containsItem(SqlConn sqlCon, String itemName) throws Exception {
		String sql = "SELECT * FROM item WHERE name = ?";
		PreparedStatement pstm = (PreparedStatement) sqlCon.getC().prepareStatement(sql);
		pstm.setString(1, itemName);
		ResultSet rs = pstm.executeQuery();
		return rs.next();
	}

	/**
	 * Add a brand new item by Item instance
	 * 
	 * @param sqlCon
	 * @param item
	 * @return
	 * @throws Exception
	 */
	public static int addItem(SqlConn sqlCon, Item item) throws Exception {
		String sql = "INSERT INTO item (name, count, price, mod, time, descript) VALUES (?, ?, ?, ?, ?, ?)";
		PreparedStatement pstm = (PreparedStatement) sqlCon.getC().prepareStatement(sql);
		pstm.setString(1, item.getName());
		pstm.setInt(2, item.getCount());
		pstm.setDouble(3, item.getUnitPrice());
		pstm.setString(4, item.getLastUser());
		pstm.setString(5, item.getLastTime());
		pstm.setString(6, item.getDescript());
		int n = pstm.executeUpdate();
		if (n > 0)
			System.out.println("Add Item successfully!");
		return n;
	}

	/**
	 * Delete one item by its name
	 * 
	 * @param sqlCon
	 * @param itemName
	 * @throws Exception
	 */
	public static void deleteItem(SqlConn sqlCon, String itemName) throws Exception {
		String sql = "DELETE FROM item WHERE name = ?";
		PreparedStatement pstm = (PreparedStatement) sqlCon.getC().prepareStatement(sql);
		pstm.setString(1, itemName);
		int n = pstm.executeUpdate();
		if (n > 0)
			System.out.println("Delete Item successfully!");
	}

	/**
	 * Update the item by one Item instance
	 * 
	 * @param sqlCon
	 * @param item
	 * @throws Exception
	 */
	public static void updateItem(SqlConn sqlCon, Item item) throws Exception {
		String sql = "UPDATE item SET count = ?, price = ?, mod = ?, time = ?, descript = ? WHERE name = ?";
		PreparedStatement pstm = (PreparedStatement) sqlCon.getC().prepareStatement(sql);
		pstm.setInt(1, item.getCount());
		pstm.setDouble(2, item.getUnitPrice());
		pstm.setString(3, item.getLastUser());
		pstm.setString(4, item.getLastTime());
		pstm.setString(5, item.getDescript());
		pstm.setString(6, item.getName());
		int n = pstm.executeUpdate();
		if (n > 0)
			System.out.println("Update Item successfully!");
	}

}
