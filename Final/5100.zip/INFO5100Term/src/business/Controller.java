package business;

import gui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Controller implements ActionListener {
	LoginWindow loginWindow = null;
	MyFrame mainFrame = null;
	SqlConn sqlCon = null;
	User user = null;

	public Controller() {
	}
	
	// launch function 
	public void run() {
		try {
			sqlCon = SqlConn.getInstance();		// single sql instance

			loginWindow = new LoginWindow();	// initial login window
			loginWindow.setVisible(true);
			// band the action
			loginWindow.getLogingBtn().addActionListener(this);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object btnSource = e.getSource();
		try {
			// Login Button function
			if (loginWindow != null && btnSource == loginWindow.getLogingBtn()) {
				String userName = loginWindow.getUserNameField().getText();
				String passWord = new String(loginWindow.getPasswordField().getPassword()); // clear text
				try {
					if (!UserHelper.containsUser(sqlCon, userName) || userName.equals("")) {	// not valid login information
						JOptionPane.showMessageDialog(null, "No Such User existed!");
						loginWindow.getUserNameField().setText("");
						loginWindow.getPasswordField().setText("");
						loginWindow.getIsAdmin().setSelected(false);
						return;
					}
					User u = UserHelper.getUserByName(sqlCon, userName);
					
					String oripw = u.getUserPW();
					if (passWord.equals(oripw) && u.isAdmin() == loginWindow.getIsAdmin().isSelected()) {	// success login
						user = new User(userName, passWord, loginWindow.getIsAdmin().isSelected());
						loginWindow.setVisible(false);
						// new main window
						mainFrame = new MyFrame();
						// add menu item actions
						mainFrame.addUser.addActionListener(this);
						mainFrame.showUser.addActionListener(this);
						mainFrame.delUser.addActionListener(this);
						mainFrame.updtUser.addActionListener(this);
						mainFrame.showItem.addActionListener(this);
						mainFrame.addItem.addActionListener(this);
						mainFrame.updtItem.addActionListener(this);
						mainFrame.delItem.addActionListener(this);
						return;
					} else {
						JOptionPane.showMessageDialog(null, "Wrong Password or Permission!");	// wrong password 
						loginWindow.getUserNameField().setText("");
						loginWindow.getPasswordField().setText("");
						loginWindow.getIsAdmin().setSelected(false);
					}
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "No such user or wrong password");
					loginWindow.getUserNameField().setText("");
					loginWindow.getPasswordField().setText("");
					loginWindow.getIsAdmin().setSelected(false);
				}
			} else if (mainFrame != null) { // menu button function
				// normal user cannot access to some menu
				if (!user.isAdmin() && (btnSource == mainFrame.addUser || btnSource == mainFrame.showUser
						|| btnSource == mainFrame.delUser)) {
					JOptionPane.showMessageDialog(null, "No permission! You're not Admin!");
					return;
				} else {
					if (btnSource == mainFrame.addUser) {
						mainFrame.changeContentPane(new AddUser(sqlCon));
					} else if (btnSource == mainFrame.showUser) {
						mainFrame.changeContentPane(new ShowUser(sqlCon));
					} else if (btnSource == mainFrame.delUser) {
						mainFrame.changeContentPane(new DelUser(sqlCon));
					} else if (btnSource == mainFrame.updtUser) {
						mainFrame.changeContentPane(new UpdateUser(user, sqlCon));
					} else if (btnSource == mainFrame.addItem) {
						mainFrame.changeContentPane(new AddItem(user, sqlCon));
					} else if (btnSource == mainFrame.showItem) {
						mainFrame.changeContentPane(new ShowItem(sqlCon));
					} else if (btnSource == mainFrame.delItem) {
						mainFrame.changeContentPane(new DelItem(sqlCon));
					} else if (btnSource == mainFrame.updtItem) {
						mainFrame.changeContentPane(new UpdateItem(user, sqlCon));
					}
				}
			}
		} catch (Exception e2) {
			// TODO: handle exception
			e2.printStackTrace();
		}
	}
}