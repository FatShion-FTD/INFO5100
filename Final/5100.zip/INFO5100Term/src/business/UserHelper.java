package business;

import java.util.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;

public class UserHelper {
	public UserHelper() {
	}

	/**
	 * Check Encrypt information
	 */
//	public static void main(String[] args) {
//		String pw = "Admin";
//		byte[] EncryptPW = UserHelper.base64Encrypt(pw);
//		System.out.println(new String(EncryptPW));
//		byte[] DecryptPW = UserHelper.base64Decrypt(EncryptPW);
//		System.out.println(new String(DecryptPW));
//		pw = "111";
//		EncryptPW = UserHelper.base64Encrypt(pw);
//		System.out.println(new String(EncryptPW));
//		DecryptPW = UserHelper.base64Decrypt(EncryptPW);
//		System.out.println(new String(DecryptPW));
//	}

	/**
	 * Add one new user by User instance
	 * 
	 * @param sqlCon
	 * @param u
	 * @throws Exception
	 */
	public static void addUser(SqlConn sqlCon, User u) throws Exception {
		String sql = "INSERT INTO user (name, password, isAdmin) VALUES (?, ?, ?)";
		PreparedStatement pstm = (PreparedStatement) sqlCon.getC().prepareStatement(sql);
		pstm.setString(1, u.getUserName());
		pstm.setString(2, new String(UserHelper.base64Encrypt(u.getUserPW())));
		pstm.setInt(3, u.isAdmin() ? 1 : 0);
		int n = pstm.executeUpdate();
		if (n > 0)
			System.out.println("Add User successfully!");
	}

	/**
	 * delete one existing user by its name
	 * 
	 * @param sqlCon
	 * @param name
	 * @throws Exception
	 */
	public static void deleteUser(SqlConn sqlCon, String name) throws Exception {
		String sql = "DELETE FROM user WHERE name = ?";
		PreparedStatement pstm = (PreparedStatement) sqlCon.getC().prepareStatement(sql);
		pstm.setString(1, name);
		int n = pstm.executeUpdate();
		if (n > 0)
			System.out.println("Delete User successfully!");
	}

	/**
	 * update user information by User instance
	 * 
	 * @param sqlCon
	 * @param u
	 * @throws Exception
	 */
	public static void updateUser(SqlConn sqlCon, User u) throws Exception {
		String sql = "UPDATE user SET password = ?, isAdmin = ? WHERE name = ?";
		PreparedStatement pstm = (PreparedStatement) sqlCon.getC().prepareStatement(sql);
		pstm.setString(1, new String(UserHelper.base64Encrypt(u.getUserPW())));
		pstm.setInt(2, u.isAdmin() ? 1 : 0);
		pstm.setString(3, u.getUserName());
		int n = pstm.executeUpdate();
		if (n > 0)
			System.out.println("Update User successfully!");
	}

	/**
	 * Get one user by its name.
	 * 
	 * @param sqlCon
	 * @param name
	 * @return
	 * @throws Exception
	 */
	public static User getUserByName(SqlConn sqlCon, String name) throws Exception {
		String sql = "SELECT * FROM user WHERE name = ?";
		PreparedStatement pstm = (PreparedStatement) sqlCon.getC().prepareStatement(sql);
		pstm.setString(1, name);
		ResultSet rs = pstm.executeQuery();
		User u = new User(rs.getString("name"), rs.getString("password"), rs.getBoolean("isAdmin"));
		u.setUserPW(new String(UserHelper.base64Decrypt(u.getUserPW().getBytes()))); // set pw in mem plaintext
		return u;
	}

	/**
	 * Check whether the user existing or not
	 * 
	 * @param sqlCon
	 * @param name
	 * @return
	 * @throws Exception
	 */
	public static boolean containsUser(SqlConn sqlCon, String name) throws Exception {
		String sql = "SELECT * FROM user WHERE name = ?";
		PreparedStatement pstm = (PreparedStatement) sqlCon.getC().prepareStatement(sql);
		pstm.setString(1, name);
		ResultSet rs = pstm.executeQuery();
		return rs.next();
	}

	/**
	 * Get all the user in the List format
	 * 
	 * @param sqlCon
	 * @return
	 * @throws Exception
	 */
	public static List<User> getAllUser(SqlConn sqlCon) throws Exception {
		String sql = "SELECT * FROM user";
		ResultSet rs = sqlCon.execQUERY(sql);
		List<User> res = new ArrayList<>();
		while (rs.next()) {
			User u = new User(rs.getString("name"), rs.getString("password"), rs.getBoolean("isAdmin"));
			u.setUserPW(new String(UserHelper.base64Decrypt(u.getUserPW().getBytes()))); // set password in memory
																							// plaintext
			res.add(u);
		}
		return res;
	}

	/**
	 * base64 Encrypt
	 * 
	 * @param content plainText
	 * @return byte[]
	 */
	public static byte[] base64Encrypt(final String content) {
		return Base64.getEncoder().encode(content.getBytes());
	}

	/**
	 * base64 Decrypt
	 * 
	 * @param encoderContent encrypted text
	 * @return byte[]
	 */
	public static byte[] base64Decrypt(final byte[] encoderContent) {
		return Base64.getDecoder().decode(encoderContent);
	}
}
