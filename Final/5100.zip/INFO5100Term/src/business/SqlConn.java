package business;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SqlConn {
	/**
	 * Initial Database information
	 */
//	public static void main(String[] args) {
//		SqlConn sqlCon = SqlConn.getInstance();
////		// Create SQL data
//		sqlCon.deleteTable();
//		sqlCon.createTable();
//		sqlCon.insertInitial();
////		sqlCon.shutDownSql();
//		// show SQL data
//		
//		sqlCon.printOut(sqlCon.execQUERY("SELECT * FROM user"));
//		sqlCon.printOut(sqlCon.execQUERY("SELECT * FROM item"));
//		sqlCon.shutDownSql();
//	}

	/**
	 * For initial table
	 */
	private void createTable() {
		String sql = "CREATE TABLE IF NOT EXISTS user (name VARCHAR(255) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL, isAdmin TINYINT(1) NOT NULL)";
		this.execUPDATE(sql);
		System.out.println("User Table Created!");

		sql = "CREATE TABLE IF NOT EXISTS item (name VARCHAR(255) NOT NULL UNIQUE, count INT NOT NULL, price DOUBLE NOT NULL, mod VARCHAR(255) NOT NULL, time VARCHAR(255) NOT NULL, descript VARCHAR(255))";
		this.execUPDATE(sql);
		System.out.println("Item Table Created!");
		return;
	}

	/**
	 * Drop existing table
	 */
	private void deleteTable() {
		String sql = "DROP TABLE user";
		this.execUPDATE(sql);
		System.out.println("User Table Dropped!");

		sql = "DROP TABLE item";
		this.execUPDATE(sql);
		System.out.println("Item Table Dropped!");
	}

	/**
	 * Insert Intial data
	 */
	private void insertInitial() {
		try {
			List<User> users = new ArrayList<>();
			users.add(new User("Admin", "Admin", true));
			users.add(new User("AAA", "AAA", false));
			users.add(new User("BBB", "BBB", false));
			users.add(new User("CCC", "CCC", false));
			users.add(new User("DDD", "DDD", false));
			users.add(new User("EEE", "EEE", false));
			users.add(new User("FFF", "FFF", false));
			users.add(new User("GGG", "GGG", false));
			users.add(new User("HHH", "HHH", false));
			users.add(new User("III", "III", false));
			users.add(new User("asdasdasdasd", "eqweqwereqwereqwrqwer", false));

			String sql = "INSERT INTO user (name, password, isAdmin) VALUES(?, ?, ?)";
			PreparedStatement pstm = (PreparedStatement) c.prepareStatement(sql);
			for (User u : users) {
				pstm.setString(1, u.getUserName());
				pstm.setString(2, new String(UserHelper.base64Encrypt(u.getUserPW())));
				pstm.setInt(3, u.isAdmin() ? 1 : 0);
				pstm.executeUpdate();
			}
			System.out.println("User Inserted!");

			List<Item> items = new ArrayList<>();
			items.add(new Item("Item A", 10, 0.5, "Desc1", "Admin"));
			items.add(new Item("Item B", 1130, 1.1235, "Desc1", "Admin"));
			items.add(new Item("Item C", 12310, 3213.5, "Desc1gfdsag", "Admin"));
			items.add(new Item("Item D", 6710, 11.4145, "Descasdfds1", "Admin"));
			items.add(new Item("Item E", 3210, 1321.5, "fasd ", "Admin"));
			items.add(new Item("Item F", 65410, 13210.5, "fadsfdsa dsafa", "Admin"));
			items.add(new Item("Item G", 9810, 414124.5, "dsghsg sdfg", "Admin"));
			items.add(new Item("Item H", 8710, 3210.5, "asfaf sadf  ", "Admin"));
			items.add(new Item("Item I", 65710, 1230.5, "dsafsfd", "Admin"));
			items.add(new Item("Item J", 8765410, 4650.5, "fsdaf", "Admin"));
			items.add(new Item("Item K", 7465710, 31230.5, "asdfsdaf", "Admin"));
			items.add(new Item("Item L", 7610, 450.5, "fadsfsa", "Admin"));
			items.add(new Item("Item M", 65710, 3120.5, "adsfasdf", "Admin"));
			items.add(new Item("Item N", 24310, 64560.5, "asdf", "Admin"));
			items.add(new Item("Item O", 76510, 8760.5, "adfs", "Admin"));
			items.add(new Item("Item P", 98710, 3210.5, "jfgk", "Admin"));
			items.add(new Item("Item Q", 21310, 8760.5, "gfdshgf", "Admin"));
			items.add(new Item("Item R", 310, 10645.5, "bvnc", "Admin"));
			items.add(new Item("Item S", 110, 2310.123215, "fdsgdfrt", "Admin"));
			items.add(new Item("Item T", 33310, 213120.5, "sdhsbvc", "Admin"));
			items.add(new Item("Item U", 1440, 6543540.15, "artret", "Admin"));

			sql = "INSERT INTO item (name, count, price, descript, time, mod) VALUES(?, ?, ?, ?, ?, ?)";
			pstm = (PreparedStatement) c.prepareStatement(sql);

			for (Item u : items) {
				pstm.setString(1, u.getName());
				pstm.setInt(2, u.getCount());
				pstm.setDouble(3, u.getUnitPrice());
				pstm.setString(4, u.getDescript());
				pstm.setString(5, u.getLastTime());
				pstm.setString(6, u.getLastUser());
				pstm.executeUpdate();
			}

			System.out.println("Item Inserted!");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Insert Error!");
			e.printStackTrace();
		}
		return;
	}

	private static SqlConn object = new SqlConn(); // singleton instance
	private Connection c = null; // SQL connection
	private Statement stmt = null; // SQL statement instance

	private SqlConn() {
		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:my.db");
			stmt = c.createStatement();
			this.printOut(this.execQUERY("SELECT * FROM user"));
			this.printOut(this.execQUERY("SELECT * FROM item"));
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Opened database successfully");
	}

	public static SqlConn getInstance() {
		return object;
	}

	public Connection getC() {
		return c;
	}

	public void setC(Connection c) {
		this.c = c;
	}

	/**
	 * Shut down the SQL connection
	 */
	public void shutDownSql() {
		try {
			stmt.close();
			c.close();
			System.out.println("Shut Down SQL connection!");
		} catch (Exception e) {
			System.out.println("Shut down database Error!");
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		}
	}

	/**
	 * Execute the update / insert / delete function
	 * 
	 * @param sql
	 */
	public void execUPDATE(String sql) {
		try {
			this.stmt.executeUpdate(sql);
		} catch (SQLException e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Mainly execute the select function, return the ResultSet, connection not yet
	 * closed
	 * 
	 * @param sql
	 * @return ResultSet rs
	 */
	public ResultSet execQUERY(String sql) {
		try {
			ResultSet rs = this.stmt.executeQuery(sql);
			return rs;
		} catch (SQLException e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Print out Result Out
	 * 
	 * @param rs
	 */
	public void printOut(ResultSet rs) {
		try {
			System.out.println("Tabel Name:	" + rs.getMetaData().getTableName(1));
			int len = rs.getMetaData().getColumnCount();
			System.out.println("=============================");
			for (int i = 1; i <= len; i++) {
				String cols = rs.getMetaData().getColumnName(i);
				System.out.print(cols + "	");
			}
			System.out.print("\n");
			while (rs.next()) {
				for (int i = 1; i <= len; i++) {
					System.out.print(rs.getString(i) + "	");
				}
				System.out.print("\n");
			}
			System.out.println("=============================");
			rs.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			e.printStackTrace();
		}
	}

}
