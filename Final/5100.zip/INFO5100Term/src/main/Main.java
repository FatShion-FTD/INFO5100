package main;
import gui.*;
import business.*;

public class Main {
	public static void main(String[] args) {
		try {
			new business.Controller().run();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
