package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.BoxLayout;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JPasswordField;

public class LoginWindow extends JFrame {

	private JPanel contentPane;
	private JTextField userNameField;
	private JPasswordField passwordField;
	private JButton logingBtn;
	private JCheckBox isAdmin;

	public JCheckBox getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(JCheckBox isAdmin) {
		this.isAdmin = isAdmin;
	}

	public JTextField getUserNameField() {
		return userNameField;
	}

	public void setUserNameField(JTextField userNameField) {
		this.userNameField = userNameField;
	}

	public JPasswordField getPasswordField() {
		return passwordField;
	}

	public void setPasswordField(JPasswordField passwordField) {
		this.passwordField = passwordField;
	}

	public JButton getLogingBtn() {
		return logingBtn;
	}

	/**
	 * Create the frame.
	 */
	public LoginWindow() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 768, 512);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 36));
		lblNewLabel.setBounds(323, 10, 116, 66);
		contentPane.add(lblNewLabel);

		logingBtn = new JButton("Login");
		logingBtn.setFont(new Font("����", Font.PLAIN, 25));
		logingBtn.setBounds(219, 338, 200, 50);
		contentPane.add(logingBtn);

		userNameField = new JTextField();
		userNameField.setFont(new Font("����", Font.PLAIN, 38));
		userNameField.setBounds(323, 135, 200, 50);
		contentPane.add(userNameField);
		userNameField.setColumns(10);

		isAdmin = new JCheckBox("isAdmin");
		isAdmin.setFont(new Font("����", Font.PLAIN, 20));
		isAdmin.setBounds(479, 352, 103, 23);
		contentPane.add(isAdmin);

		passwordField = new JPasswordField();
		passwordField.setBounds(323, 236, 200, 50);
		contentPane.add(passwordField);

		JLabel lblNewLabel_1 = new JLabel("UserName:");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 38));
		lblNewLabel_1.setBounds(123, 135, 200, 50);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Password:");
		lblNewLabel_2.setFont(new Font("����", Font.PLAIN, 38));
		lblNewLabel_2.setBounds(123, 228, 200, 50);
		contentPane.add(lblNewLabel_2);
	}
}
