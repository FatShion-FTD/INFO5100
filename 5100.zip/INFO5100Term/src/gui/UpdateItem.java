package gui;

import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JPanel;

import business.Item;
import business.ItemHelper;
import business.SqlConn;
import business.User;

import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;

public class UpdateItem extends JPanel implements ActionListener {
	private SqlConn sqlCon = null;
	private User user = null;

	private JTextField countField;
	private JTextField PriceField;
	JTextArea DescriptionField;
	JButton btn;
	JComboBox<String> comboBox;

	Object[][] data = null;
	String[] names = null;

	/**
	 * Create the panel.
	 * @throws Exception 
	 */
	public UpdateItem(User user, SqlConn sql) throws Exception {
		this.sqlCon = sql;
		this.user = user;

		this.setLayout(null);

		data = ItemHelper.getItemsByObject(this.sqlCon);
		names = this.getItemNames(data);

		comboBox = new JComboBox<String>(names);
		comboBox.setBounds(204, 64, 178, 41);
		comboBox.addActionListener(this);
		add(comboBox);

		JLabel lblNewLabel = new JLabel("Select Item");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel.setBounds(32, 66, 129, 32);
		add(lblNewLabel);

		JLabel lblItemCount = new JLabel("Item Count");
		lblItemCount.setFont(new Font("����", Font.PLAIN, 20));
		lblItemCount.setBounds(32, 143, 129, 32);
		add(lblItemCount);

		JLabel lblItemUnitPrice = new JLabel("Item Unit Price");
		lblItemUnitPrice.setFont(new Font("����", Font.PLAIN, 20));
		lblItemUnitPrice.setBounds(32, 226, 166, 32);
		add(lblItemUnitPrice);

		JLabel lblItemDescription = new JLabel("Item Description");
		lblItemDescription.setFont(new Font("����", Font.PLAIN, 20));
		lblItemDescription.setBounds(429, 72, 178, 32);
		add(lblItemDescription);

		countField = new JTextField();
		countField.setBounds(208, 143, 174, 32);
		add(countField);
		countField.setColumns(10);

		PriceField = new JTextField();
		PriceField.setColumns(10);
		PriceField.setBounds(208, 226, 174, 32);
		add(PriceField);

		DescriptionField = new JTextArea();
		DescriptionField.setBounds(430, 132, 238, 157);
		add(DescriptionField);

		btn = new JButton("Update");
		btn.setFont(new Font("����", Font.PLAIN, 20));
		btn.setBounds(283, 304, 129, 63);
		btn.addActionListener(this);
		add(btn);

		// TODO: �õ�����Item Name, ������Ⱦ, ʹ�õ�һ������
		// ���԰汾
		int index = comboBox.getSelectedIndex();
		countField.setText(data[index][1] + "");
		PriceField.setText(data[index][2] + "");
		DescriptionField.setText(data[index][3] + "");
	}

	private String[] getItemNames(Object[][] objs) {
		String[] res = new String[objs.length];
		for (int i = 0; i < objs.length; i++) {
			res[i] = (String) objs[i][0];
		}
		return res;
	}
	
	private void setInfo() {
		String selectedItem = (String) comboBox.getSelectedItem();
		System.out.println("Select:	" + selectedItem);
		Item item;
		try {
			item = ItemHelper.getOneItem(sqlCon, selectedItem);
			countField.setText(String.valueOf(item.getCount()));
			PriceField.setText(String.valueOf(item.getUnitPrice()));
			DescriptionField.setText(String.valueOf(item.getDescript()));
		} catch (Exception e) {
			// TODO Auto-generated catch block
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source == btn) { // Button Function
			try {
				String countStr = countField.getText();
				String priceStr = PriceField.getText();
				String des = DescriptionField.getText();
				String selectedItem = (String) comboBox.getSelectedItem();
				
				int cnt = Integer.parseInt(countStr);
				double price = Double.parseDouble(priceStr);
				
				if (cnt < 0 || price < 0) {
					JOptionPane.showMessageDialog(null, "Invalid Value! Check Count and Price!");
					this.setInfo();
					return;
				}
				Item item = new Item(selectedItem, cnt, price, des, user.getUserName());				
				ItemHelper.updateItem(sqlCon, item);
				JOptionPane.showMessageDialog(null, "Item Information successfully updated!");
			} catch (Exception e2) {
				JOptionPane.showMessageDialog(null, "Illegal input! Input again");
				this.setInfo();
			}
		} else if (source == comboBox) { // Combox Function
			this.setInfo();
		}
	}
}
