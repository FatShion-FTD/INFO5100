package gui;

import java.awt.Font;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import business.SqlConn;
import business.User;
import business.UserHelper;

public class UpdateUser extends JPanel implements ActionListener {
	private SqlConn sqlCon = null;
	private User user = null;
	private JTextField userNameField;
	private JTextField passwordField;
	private boolean isAdmin = false;
	private JCheckBox adminCheckBox;
	private JButton addBtn;

	/**
	 * Create the panel.
	 */
	public UpdateUser(User user, SqlConn sql) {
		this.sqlCon = sql;
		this.user = user;
		this.isAdmin = user.isAdmin();

		this.setLayout(null);

		JLabel lblNewLabel = new JLabel("Update User Password and Permission");
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 30));
		lblNewLabel.setBounds(100, 10, 600, 100);
		this.add(lblNewLabel);

		Label label1 = new Label("User Name:");
		label1.setFont(new Font("����", Font.PLAIN, 30));
		label1.setBounds(80, 135, 250, 50);
		this.add(label1);

		Label label2 = new Label("New User Password:");
		label2.setFont(new Font("����", Font.PLAIN, 30));
		label2.setBounds(80, 228, 300, 50);
		this.add(label2);

		userNameField = new JTextField();
		userNameField.setColumns(15);
		userNameField.setFont(new Font("����", Font.PLAIN, 30));
		userNameField.setBounds(450, 135, 250, 50);
		userNameField.setEnabled(isAdmin); // only admin can change
		userNameField.setText(user.getUserName());
		this.add(userNameField);

		passwordField = new JTextField();
		passwordField.setColumns(15);
		passwordField.setBounds(450, 236, 250, 50);
		passwordField.setText(user.getUserPW());
		this.add(passwordField);

		if (isAdmin) {
			adminCheckBox = new JCheckBox("Is Admin Permission");
			adminCheckBox.setFont(new Font("����", Font.PLAIN, 20));
			adminCheckBox.setBounds(450, 352, 250, 50);
			this.add(adminCheckBox);
		}

		addBtn = new JButton("Update User");
		addBtn.setFont(new Font("����", Font.PLAIN, 25));
		addBtn.setBounds(219, 338, 200, 50);
		addBtn.addActionListener(this);
		this.add(addBtn);

	}

	private void setClear() {
		if (isAdmin)
			userNameField.setText("");
		passwordField.setText("");
		adminCheckBox.setSelected(false);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			Object source = e.getSource();
			if (source == addBtn) {
				if (!isAdmin) { // normal user, only update password
					String newPW = passwordField.getText();
					UserHelper.updateUser(sqlCon, new User(user.getUserName(), newPW, isAdmin));
					JOptionPane.showMessageDialog(null, "Password successfully updated!");
				} else {
					String userName = userNameField.getText();
					String userPW = passwordField.getText();
					boolean adminPermission = adminCheckBox.isSelected();
					if (!UserHelper.containsUser(sqlCon, userName)) {
						JOptionPane.showMessageDialog(null, "No Such User Existed!");
						this.setClear();
						return;
					}
					UserHelper.updateUser(sqlCon, new User(userName, userPW, adminPermission));
					this.setClear();
					JOptionPane.showMessageDialog(null, "User Password and Permission successfully updated!");
				}
			}
		} catch (Exception e2) {
			e2.printStackTrace();
		}
	}
}
