package gui;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import business.Item;
import business.ItemHelper;
import business.SqlConn;
import business.User;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;

public class AddItem extends JPanel implements ActionListener {
	private SqlConn sqlCon = null;
	private User user = null;
	private JTextField nameText;
	private JTextField countText;
	private JTextField priceText;
	private JTextArea textArea;
	private JButton btn;

	/**
	 * Add items. If not exist, create
	 */
	public AddItem(User user, SqlConn sql) {
		this.sqlCon = sql;
		this.user = user;
		this.setLayout(null);

		JLabel lblNewLabel = new JLabel("Add New Item");
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 36));
		lblNewLabel.setBounds(250, 10, 250, 100);
		this.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Item Name");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(79, 178, 113, 38);
		add(lblNewLabel_1);

		JLabel lblNewLabel_3 = new JLabel("Description");
		lblNewLabel_3.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(412, 169, 122, 57);
		add(lblNewLabel_3);

		JLabel lblNewLabel_5 = new JLabel("Add Brand New Items to the Inventory.");
		lblNewLabel_5.setFont(new Font("����", Font.PLAIN, 25));
		lblNewLabel_5.setBounds(144, 92, 579, 56);
		add(lblNewLabel_5);

		JLabel lblNewLabel_1_1 = new JLabel("Item Count");
		lblNewLabel_1_1.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_1_1.setBounds(79, 260, 113, 38);
		add(lblNewLabel_1_1);

		JLabel lblNewLabel_1_1_1 = new JLabel("Price");
		lblNewLabel_1_1_1.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_1_1_1.setBounds(79, 337, 113, 38);
		add(lblNewLabel_1_1_1);

		nameText = new JTextField();
		nameText.setBounds(229, 178, 102, 43);
		nameText.setColumns(10);
		add(nameText);

		countText = new JTextField();
		countText.setBounds(229, 252, 102, 38);
		add(countText);
		countText.setColumns(10);

		priceText = new JTextField();
		priceText.setColumns(10);
		priceText.setBounds(229, 337, 102, 38);
		add(priceText);

		btn = new JButton("Add");
		btn.setFont(new Font("����", Font.PLAIN, 25));
		btn.setBounds(326, 385, 122, 56);
		btn.addActionListener(this);
		add(btn);

		textArea = new JTextArea();
		textArea.setBounds(412, 236, 238, 139);
		add(textArea);
	}

	private void setClear() {
		nameText.setText("");
		countText.setText("");
		textArea.setText("");
		priceText.setText("");
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source == btn) {
			try {
				String itemName = nameText.getText();
				String itemCount = countText.getText();
				String description = textArea.getText();
				String price = priceText.getText();
				if (ItemHelper.containsItem(sqlCon, itemName)) {
					JOptionPane.showMessageDialog(null, "Item already existed!");
					this.setClear();
					return;
				}
				// check negative value
				if (Integer.parseInt(itemCount) < 0 || Double.parseDouble(price) < 0) {
					JOptionPane.showMessageDialog(null, "Invalid Value! Check Count and Price!");
					this.setClear();
					return;
				}
				Item item = new Item(itemName, Integer.parseInt(itemCount), Double.parseDouble(price), description,
						this.user.getUserName());
				ItemHelper.addItem(sqlCon, item);
				JOptionPane.showMessageDialog(null, "Item successfully added!");
			} catch (Exception e2) {
				this.setClear();
				JOptionPane.showMessageDialog(null, "Illegal input! Input again");
			}
		}
	}
}
