package business;

import java.util.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;

public class UserHelper {
	public UserHelper() {
	}

//	public static void getEncrpyptPassword(char[]) {
//		// TODO: get the original password
//	}

	public static void addUser(SqlConn sqlCon, User u) throws Exception {
		String sql = "INSERT INTO user (name, password, isAdmin) VALUES (?, ?, ?)";
		PreparedStatement pstm = (PreparedStatement) sqlCon.getC().prepareStatement(sql);
		pstm.setString(1, u.getUserName());
		pstm.setString(2, u.getUserPW());
		pstm.setInt(3, u.isAdmin() ? 1 : 0);
		int n = pstm.executeUpdate();
		if (n > 0)
			System.out.println("Add User successfully!");
	}

	public static void deleteUser(SqlConn sqlCon, String name) throws Exception {
		String sql = "DELETE FROM user WHERE name = ?";
		PreparedStatement pstm = (PreparedStatement) sqlCon.getC().prepareStatement(sql);
		pstm.setString(1, name);
		int n = pstm.executeUpdate();
		if (n > 0)
			System.out.println("Delete User successfully!");
	}

	public static void updateUser(SqlConn sqlCon, User u) throws Exception {
		String sql = "UPDATE user SET password = ?, isAdmin = ? WHERE name = ?";
		PreparedStatement pstm = (PreparedStatement) sqlCon.getC().prepareStatement(sql);
		pstm.setString(1, u.getUserPW());
		pstm.setInt(2, u.isAdmin() ? 1 : 0);
		pstm.setString(3, u.getUserName());
		int n = pstm.executeUpdate();
		if (n > 0)
			System.out.println("Update User successfully!");
	}

	public static User getUserByName(SqlConn sqlCon, String name) throws Exception {
		String sql = "SELECT * FROM user WHERE name = ?";
		PreparedStatement pstm = (PreparedStatement) sqlCon.getC().prepareStatement(sql);
		pstm.setString(1, name);
		ResultSet rs = pstm.executeQuery();
		User u = new User(rs.getString("name"), rs.getString("password"), rs.getBoolean("isAdmin"));
		return u;
	}

	public static boolean containsUser(SqlConn sqlCon, String name) throws Exception {
		String sql = "SELECT * FROM user WHERE name = ?";
		PreparedStatement pstm = (PreparedStatement) sqlCon.getC().prepareStatement(sql);
		pstm.setString(1, name);
		ResultSet rs = pstm.executeQuery();
		return rs.next();
	}

	public static List<User> getAllUser(SqlConn sqlCon) throws Exception {
		String sql = "SELECT * FROM user";
		ResultSet rs = sqlCon.execQUERY(sql);
		List<User> res = new ArrayList<>();
		while (rs.next()) {
			res.add(new User(rs.getString(1), rs.getString(2), rs.getInt(3) == 1 ? true : false));
		}
		return res;
	}

	/**
	 * base64����
	 * 
	 * @param content ����������
	 * @return byte[]
	 */
	public static byte[] base64Encrypt(final String content) {
		return Base64.getEncoder().encode(content.getBytes());
	}

	/**
	 * base64����
	 * 
	 * @param encoderContent �Ѽ�������
	 * @return byte[]
	 */
	public static byte[] base64Decrypt(final byte[] encoderContent) {
		return Base64.getDecoder().decode(encoderContent);
	}
}
