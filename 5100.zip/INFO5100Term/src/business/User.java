package business;

/**
 * Table format: name varchar(255), 
 * password varchar(255),
 * isAdmin tinyint(1)
 * 
 */
public class User {
	private String userName;
	private String userPW;
	private boolean isAdmin = false;
	
	
	public boolean isAdmin() {
		return isAdmin;
	}

	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPW() {
		return userPW;
	}

	public void setUserPW(String userPW) {
		this.userPW = userPW;
	}

	public User() {

	}

	public User(String name, String pw, boolean isAdmin) {
		this.userName = name;
		this.userPW = pw;
		this.isAdmin = isAdmin;
	}
}
