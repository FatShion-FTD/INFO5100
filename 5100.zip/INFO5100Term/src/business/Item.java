package business;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * name varchar(255) count int price double mod varchar(255) time varchar(255)
 * descript varchar(255)
 * 
 * @author lmc
 *
 */
public class Item {
	SimpleDateFormat sdf = new SimpleDateFormat();;// ��ʽ��ʱ��

	private String name = "DefaultName";
	private String descript = "DefaultDescription";
	private int count = 0;
	private double unitPrice = 0;
	private String lastTime = "Unknown";
	private String lastUser = "Unknown";
	public static int LEN = 6;

	public Item(String n, int c, double p, String d, String mod) {
		sdf.applyPattern("yyyy-MM-dd HH:mm");

		this.name = n;
		this.descript = d;
		this.count = c;
		this.unitPrice = p;

		Date date = new Date();// ��ȡ��ǰʱ��
		this.lastTime = sdf.format(date);
		this.lastUser = mod;
	}
	
	public Item(String n, int c, double p, String d, String t, String m) {
		this.name = n;
		this.count = c;
		this.unitPrice = p;
		this.descript = d;
		this.lastTime = t;
		this.lastUser = m;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescript() {
		return descript;
	}

	public void setDescript(String descript) {
		this.descript = descript;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getLastTime() {
		return lastTime;
	}

	public void setLastTime(String lastTime) {
		this.lastTime = lastTime;
	}

	public String getLastUser() {
		return lastUser;
	}

	public void setLastUser(String lastUser) {
		this.lastUser = lastUser;
	}

}
